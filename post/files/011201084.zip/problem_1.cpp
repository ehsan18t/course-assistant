#include<bits/stdc++.h>
using namespace std;
/*
 test case
7
0010110
0001011
output : 2
*/

int main(){
    int n;
    cin>>n;
    char s[n],t[n];
    cin>>s;
    cin>>t;
    int counter = 0;
    int indexT = 0,indexS = 0,chaker=0;
    // cout<<s<<endl;
    // cout<<t<<endl;
    for(int i=indexS;i<n;){
        //cout<<i<<endl;
        for(int j=indexT;j<n;j++){
            if(s[i]==t[j] && chaker==0){
                i++;
                //cout<<i<<endl;
            }
            else if(s[i]==t[j] && chaker==1){
                  counter++;
                  chaker = 0;
                  indexT = j;

            }
            else if(s[i]!=t[j]){
                //cout<<s[i]<<" "<<t[j]<<endl;
               //cout<<"index "<<i<<endl; 
               chaker=1;
               i++;  

            }
        }
    }
    if(chaker==1)counter++;
    cout<<counter<<endl;
}